sap.ui.define([
	"project1/test/unit/controller/app.controller"
], function () {
	"use strict";
});
